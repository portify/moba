#!/bin/sh
love . server
