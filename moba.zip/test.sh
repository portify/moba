#!/bin/sh
love . local_loop server &
love . local_loop
