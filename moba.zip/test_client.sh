#!/bin/sh
love .
