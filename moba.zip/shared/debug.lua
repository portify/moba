local parent = print

function print(...)
    -- Debugging hooks
    return parent(...)
end
